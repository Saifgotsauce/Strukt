---
title: "Who builds Shambhala: the crew behind BC's farm festival"
description: "Shambhala runs on a family farm near Salmo, BC. We went through its public crew list to credit the people who build it, from stage directors to harm reduction."
pubDate: 2026-11-01
category: "The scene"
tags: ["Shambhala", "Shambhala Music Festival", "British Columbia", "Salmo", "harm reduction", "ANKORS", "festival crew", "credits"]
draft: false
---

<!-- Desk: Night. Words: STRUKT Night desk. -->

In 2006, **Jimmy Bundschuh** walked into Nelson City Hall and asked the mayor whether his festival could use the town's wastewater plant. [The Tyee told that story](https://thetyee.ca/News/2014/05/17/Shambhala-Festival/) as an example of how a wild electronic music festival won over the small towns around it. We think it says something else too. Festivals are built out of a thousand unglamorous problems like that one, and somebody has to go and solve each of them.

Shambhala is, [according to Wikipedia](https://en.wikipedia.org/wiki/Shambhala_(music_festival)), the largest and one of the longest-running electronic music events in Canada, and it publishes something few festivals do: a public list of the people on its team. So we're starting STRUKT's festival credits here, at home.

## The farm and the family

Shambhala takes place on [Salmo River Ranch](https://en.wikipedia.org/wiki/Shambhala_(music_festival)), the Bundschuh family's 500-acre farm in the West Kootenay mountains near Nelson, and it has run since 1998. **Rick and Sue Bundschuh** [bought the ranch when their son Jimmy was 14](https://thetyee.ca/News/2014/05/17/Shambhala-Festival/). When Jimmy started a festival there, he told [VICE](https://www.vice.com/en/article/we-sit-down-with-shambhalas-founder/), it was a locals-only affair with Kootenay DJs and no budget at all. His father had always encouraged his kids to be entrepreneurs rather than work for someone else, Jimmy said, and he got what he asked for.

By 2014 the festival was drawing around 10,000 people; [by 2019](https://edm.com/interviews/unraveling-mysteries-shambhala-music-festival/) it expected around 15,000. It has stayed independent the whole way, a model Jimmy has described to Billboard as the [opposite of most festivals](https://www.billboard.com/music/music-news/shambhala-jimmy-bundschuh-founder-interview-8526945/). He has also explained how leadership works there: people start as volunteers and work their way up the ranks as they shine.

## The credits

These are the people listed on [Shambhala's public crew page](https://crew.shambhalamusicfestival.com/people) as of this week, with the roles they're listed under. We've grouped them by what they build.

**Running the festival**
- **Jimmy Bundschuh**, Founder
- **Neil MacLeod**, Chief Executive Officer
- **Rachel Randle**, Executive Operations Manager
- **Holly Nesbitt**, Project Manager
- **Taylor Kaufmann**, Executive Assistant

**The stages**
- **Rob Campbell**, Pagoda Stage Director
- **Michael Paine** and **Sara Spicer**, Living Room Stage Directors
- **Mike Stewart**, Amp Stage Director
- **Byron Whitlaw**, Grove Stage Director
- **Christine Hunter**, Entertainment Director

**The site**
- **Christa McDiarmid**, Site Director
- **Juby Bryant**, Site Manager
- **Adam Mac Neil**, Equipment Operator and Carpenter
- **Alex Lawrence**, Equipment Operator
- **Kate Tupper**, Farm Dec Manager
- **Tom Craft**, Tech Director
- **Kendall Fahey**, Technical Support Manager
- **Mitch Facer**, Chief Software Officer

**Keeping people safe**
- **Stacey Lock**, Harm Reduction Director

**The look and the word**
- **Andrew Fry**, Graphic Designer
- **Brittany Smyth-Jones**, Chief Marketing Officer
- **Katie Kershaw**, Marketing Manager
- **Bryce Winters**, Marketing Coordinator

**Making it all work**
- **Madison MacLeod**, Commercial Director
- **Mia Callingham**, Retail and Commercial Operations Coordinator
- **Noel Paul**, Procurement Specialist
- **Nicole Seaboyer**, Human Resources Director
- **Renae Hering**, Human Resources Manager
- **Katie Baxter**, HR Coordinator
- **Georgie Garby**, HR Administrator
- **Shelley MacKnight**, Finance Director
- **Susan Wilson**, Finance Administrator
- **Connie Owens**, Bookkeeper

That's the year-round team. It is nowhere near everyone.

## The people who made harm reduction normal

Shambhala's best-known contribution to festival culture didn't come from a stage. For more than two decades it has worked with **ANKORS**, the AIDS Network Kootenay Outreach and Support Society, to offer free, anonymous drug checking on site, alongside a sanctuary space for anyone having a hard time.

That work has names. In 2014, **Chloe Sage** of ANKORS told The Tyee that harm reduction at Shambhala had grown from a two-person team in 2002 to 35 volunteers. In 2019, **Julie Soleil-Meeson**, an ANKORS volunteer and harm reduction director, [told Conscious Electronic](https://consciouselectronic.com/2019/08/09/festival-spotlight-how-shambhala-became-a-global-pioneer-in-harm-reduction/) why acknowledging drug use beats pretending it isn't happening. [EDM.com has reported](https://edm.com/interviews/unraveling-mysteries-shambhala-music-festival/) that by working with Health Canada and other official bodies, the festival and the provincial government pioneered the legal framework for on-site pill testing, something the US RAVE Act makes illegal at American festivals.

Today the festival's own **Harm Reduction Director** is **Stacey Lock**.

*We couldn't find the names of ANKORS's current drug checking team at Shambhala, or of the two people who started that work in 2002.*

## The names still missing

The public crew list is a rare thing, and we're grateful it exists. It still leaves out most of the people who build Shambhala each summer:

- *The directors of the Fractal Forest and the Village, two of its best-known stages, aren't on the public list.*
- *The sound, lighting and video crews on every stage.*
- *The builders and decor teams behind each stage's design.*
- *The volunteers, who, by Jimmy Bundschuh's own account, are where the festival's leaders come from.*
- *The medical, security and sanctuary teams.*

The Tyee's 2014 coverage also pictured **Anna Bundschuh** and **Corrine Zawaduk** of Shambhala. *We couldn't confirm their roles.*

If you've built any part of Shambhala, from a stage to a sanctuary shift, [send us your name and what you did](/call-for-creatives). We'll add you to these credits, and we'll keep adding until the list looks like the festival actually does.

<!-- REDDIT DATA: add first-hand stories from Shambhala crew and volunteers posted publicly on forums or r/shambhala, credited to each thread. -->

## Sources

- Shambhala crew list, [Shambhala Music Festival](https://crew.shambhalamusicfestival.com/people)
- "How a Wild Electronic Music Fest Won over Its Small-Town Host", [The Tyee](https://thetyee.ca/News/2014/05/17/Shambhala-Festival/)
- Shambhala (music festival), [Wikipedia](https://en.wikipedia.org/wiki/Shambhala_(music_festival))
- "From Zero Budget to Infinite Awe", [VICE](https://www.vice.com/en/article/we-sit-down-with-shambhalas-founder/)
- "Unraveling the Mysteries of Shambhala Music Festival", [EDM.com](https://edm.com/interviews/unraveling-mysteries-shambhala-music-festival/)
- Jimmy Bundschuh interview, [Billboard](https://www.billboard.com/music/music-news/shambhala-jimmy-bundschuh-founder-interview-8526945/)
- "How Shambhala became a global pioneer in harm reduction", [Conscious Electronic](https://consciouselectronic.com/2019/08/09/festival-spotlight-how-shambhala-became-a-global-pioneer-in-harm-reduction/)
