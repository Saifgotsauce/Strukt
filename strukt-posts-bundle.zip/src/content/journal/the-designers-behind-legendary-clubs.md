---
title: "The designers behind Studio 54, the Paradise Garage and the Haçienda"
description: "Everyone knows the DJs. Far fewer know the lighting, sound and interior designers who built the rooms that made those nights legendary."
pubDate: 2026-10-29
category: "The scene"
tags: ["club history", "Studio 54", "Paradise Garage", "Haçienda", "lighting design", "sound design", "club design"]
heroImage: "https://images.unsplash.com/photo-1630395822310-15b171c9a85f?auto=format&fit=crop&w=2000&q=70"
heroAlt: "Silhouettes of a crowd with hands raised under stage lights"
heroCredit: "Photo: Kajetan Sumila, Unsplash"
draft: false
---

<!-- Desk: Archive. Words: STRUKT Archive desk. -->

The most copied pattern in club design started as a safety notice. When Ben Kelly designed the interior of the Haçienda in Manchester, the old warehouse had heavy iron columns standing in the middle of the floor, and he painted them in yellow and black diagonal stripes. "We literally put the stripes on to mark the columns as a danger," he later told [Wallpaper](https://wallpaper.com/design/ben-kelly-interview). Four decades on, those stripes have turned up on designer clothing and football shirts, and Kelly has complained publicly that he was [neither credited nor consulted](https://modernmooch.com/2025/01/) when one of those shirts borrowed them.

That small story holds the whole problem this magazine was started to fix. The nights that became legends were built by teams, and history kept the names of the people in the booth. Here are some of the others.

## The room: Ben Kelly and the Haçienda

The [Haçienda](https://en.wikipedia.org/wiki/The_Ha%C3%A7ienda) opened on 21 May 1982 in a former yacht builder's showroom and warehouse, run by Factory Records and the band New Order. Factory's graphic designer, Peter Saville, recommended Kelly for the job, and Kelly treated the building like a street. Alongside the striped columns, he used traffic bollards to mark the change in level around the dance floor, borrowing the [language of construction zones](https://vitra.com/en-de/magazine/details/dance) to turn an industrial shell into a stage for the crowd. The Vitra Design Museum, which put the club at the centre of its exhibition on nightclub design, notes that Kelly called it "a people's place".

The club also had a sound and lighting team that almost nobody remembers. The installation was done by Martin Disney Associates and later by Eddie Akka of Akwil Ltd. Those names appear in reference books and almost nowhere else.

Even the club's spelling was a piece of design. Spanish doesn't use the cedilla, but Factory gave the Haçienda one anyway because "çi" looks like 51, the club's number in the Factory catalogue, FAC 51.

## The light: Joshua White and the Fillmore East

Long before club lighting meant moving heads and lasers, it meant oil, water and coloured dye on a projector. From the night Bill Graham's Fillmore East opened in New York in March 1968, the [Joshua Light Show](https://en.wikipedia.org/wiki/Joshua_White_(artist)) played behind every act on the bill.

Joshua White had studied lighting at film and theatre school and worked in discothèques before the Fillmore. According to the [University of Iowa's Downtown Pop Underground archive](https://dsps.lib.uiowa.edu/downtownpopunderground/person/joshua-white/), he travelled to San Francisco in 1967 to see the light shows there and came away unimpressed by how static they were. Back in New York, his team built something more alive, mixing liquid projections, colour wheels, slides and film into visuals that moved with each band in real time. Because acts usually played two shows a night, often for several nights running, the team could experiment and refine their work in front of a crowd almost constantly.

Their work reached further than most people realise. Images from the light show appear on the back cover of Jimi Hendrix's *Band of Gypsys* and the front cover of Iron Butterfly's *In-A-Gadda-Da-Vida*, as [Untapped New York](https://untappedcities.com/2021/10/08/secrets-of-fillmore-east/6/) has documented. Millions of people own a piece of Joshua White's work without ever having heard his name.

## The rig: Jules Fisher, Paul Marantz and Studio 54

[Studio 54](https://opencollection.brooklynmuseum.org/exhibitions/3392) ran for thirty-three months, from April 1977 to February 1980, in a former theatre and television studio on West 54th Street. Its owners, Steve Rubell and Ian Schrager, wanted the club to feel like stagecraft, so they hired theatre people. Jules Fisher and Paul Marantz had lit Tony Award-winning Broadway productions and earlier clubs such as Electric Circus and Arthur, and they designed a kinetic lighting system for the dance floor.

Schrager has said the split was deliberate. The interiors got soft architectural light, and the dance floor got as much theatrical lighting as the room could hold. In an [interview with the Design Museum Frankfurt](https://www.design-museum.de/en/ueber-design/interviews/detailseiten/interview-ian-schrager.html), he called the combination "the linchpin of the club's success." When the club was renovated in 1978, Fisher and Marantz brought in the fanned neon backdrop from the original Broadway production of *Chicago* after the show closed.

The building itself had its own team. Architect Scott Bromley converted the old CBS studio and worked with interior designer Ron Doud, and Bobby DaSilva was the club's lighting director during the Rubell and Schrager years. Marantz went on to co-found the lighting firm Fisher Marantz Stone and to light the Times Square New Year's Eve ball and the Tribute in Light at the World Trade Center site. He died in May 2025.

## The sound: Richard Long and the Paradise Garage

If you've ever stood in front of a club system and felt the bass in your chest, you've felt Richard Long's influence. Long started out as the repair man for sound designer Alex Rosner, sent out whenever a club's system broke down mid-night, and became [the preeminent sound designer of the disco era](https://en.wikipedia.org/wiki/Richard_Long_(sound_designer)), installing systems at Studio 54, Max's Kansas City and clubs around the world.

His flagship was the Paradise Garage, the New York club where Larry Levan held his residency from 1977 to 1987. Long built the system around the room's acoustics and Levan's way of playing, including a custom bass horn named the Levan Horn. When other engineers criticised him for handing a DJ direct control over so much power, Long answered with an analogy that [Design Observer](https://designobserver.com/in-paradise/) has quoted: in a club, the sound system is the orchestra and the DJ is the conductor.

That system shaped clubs for decades. Justin Berkmann, who co-founded London's Ministry of Sound, [told NPR](https://www.npr.org/sections/therecord/2011/12/06/143205414/remembering-larry-levan-the-jimi-hendrix-of-dance-music) that Ministry was largely modelled on the Garage, and that its system was installed by an assistant to one of Long's original associates. Long died in 1986, a year before the Garage closed.

## What the history leaves out

None of this takes anything away from the DJs. Larry Levan's sets were genuinely extraordinary, and the crowds came for the music. But the way club history gets told, through flyers, documentaries and anniversary playlists, treats the room as a backdrop rather than as work. The lighting is "the lights". The sound is "the system". The interior is "the vibe". Each of those was a person with a name, a budget, a deadline and a set of problems to solve.

There's a practical cost to forgetting them, too. The people starting out today in lighting, sound, set design and visual art learn their craft from the work of people they can't name, which makes the craft harder to trace, study and build on. A scene that credits only the people on the flyer quietly teaches everyone else that their work doesn't count.

That's the work STRUKT is here to do, one credit at a time. If you build the rooms people dance in, in any role, at any scale, [we want to hear from you](/call-for-creatives).

As for Kelly's stripes, they're still the best-known image of the Haçienda, more than a quarter of a century after the club closed. He put them there so nobody would dance into a column.

<!-- REDDIT DATA: add a short section of present-day crew members on Reddit naming the uncredited people behind nights they loved, credited to each thread. -->

## Sources

- Ben Kelly interview, [Wallpaper](https://wallpaper.com/design/ben-kelly-interview)
- The Haçienda, [Wikipedia](https://en.wikipedia.org/wiki/The_Ha%C3%A7ienda)
- "Dance!", [Vitra Design Museum magazine](https://vitra.com/en-de/magazine/details/dance)
- Joshua White, [Downtown Pop Underground, University of Iowa](https://dsps.lib.uiowa.edu/downtownpopunderground/person/joshua-white/)
- Secrets of the Fillmore East, [Untapped New York](https://untappedcities.com/2021/10/08/secrets-of-fillmore-east/6/)
- Studio 54: Night Magic, [Brooklyn Museum](https://opencollection.brooklynmuseum.org/exhibitions/3392)
- Interview with Ian Schrager, [Design Museum Frankfurt](https://www.design-museum.de/en/ueber-design/interviews/detailseiten/interview-ian-schrager.html)
- Richard Long, [Wikipedia](https://en.wikipedia.org/wiki/Richard_Long_(sound_designer))
- "In Paradise", [Design Observer](https://designobserver.com/in-paradise/)
- Remembering Larry Levan, [NPR](https://www.npr.org/sections/therecord/2011/12/06/143205414/remembering-larry-levan-the-jimi-hendrix-of-dance-music)
